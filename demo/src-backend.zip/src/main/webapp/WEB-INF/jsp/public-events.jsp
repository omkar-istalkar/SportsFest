<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>SportsFest - Events</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-5">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Available Events</h2>
        <a href="/" class="btn btn-outline-dark btn-sm">
            Admin Login
        </a>
    </div>

    <div class="row g-4">

        <c:forEach var="event" items="${events}">
            <div class="col-md-4">

                <div class="card shadow-sm h-100">
                    <div class="card-body">

                        <h5 class="card-title">${event.name}</h5>

                        <p class="card-text text-muted">
                            ${event.description}
                        </p>

                        <p>
                            <strong>Deadline:</strong> ${event.deadline}
                        </p>

                        <a href="/register/${event.id}" 
                           class="btn btn-primary w-100">
                            Register
                        </a>

                    </div>
                </div>

            </div>
        </c:forEach>

    </div>

    <div class="text-center mt-4">
        <a href="/check-status" class="btn btn-secondary">
            Check Registration Status
        </a>
    </div>

</div>

</body>
</html>