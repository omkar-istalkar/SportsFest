<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
    <title>SportsFest Admin</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f3f4f6;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            height: 100vh;
            background: #0f172a;
            position: fixed;
            color: white;
            padding-top: 20px;
        }

        .sidebar h5 {
            padding-left: 20px;
            font-weight: 600;
        }

        .sidebar small {
            padding-left: 20px;
            color: #94a3b8;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 20px;
            color: #cbd5e1;
            text-decoration: none;
            border-radius: 8px;
            margin: 6px 15px;
            transition: 0.3s;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #1d4ed8;
            color: white;
        }

        /* Main Area */
        .main {
            margin-left: 260px;
            padding: 25px 35px;
        }

        /* Topbar */
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .search-input {
            background: #e5e7eb;
            border: none;
            border-radius: 50px;
            padding: 10px 20px;
            width: 350px;
        }

        .profile-circle {
            width: 40px;
            height: 40px;
            background: #2563eb;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        /* Cards */
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.05);
            transition: 0.3s;
            border-top: 4px solid transparent;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .border-blue { border-top-color: #2563eb; }
        .border-green { border-top-color: #16a34a; }
        .border-orange { border-top-color: #f59e0b; }
        .border-red { border-top-color: #ef4444; }

        .icon-box {
            width: 45px;
            height: 45px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
            font-size: 18px;
        }

        .bg-soft-blue { background: #dbeafe; color: #2563eb; }
        .bg-soft-green { background: #dcfce7; color: #16a34a; }
        .bg-soft-orange { background: #fef3c7; color: #f59e0b; }
        .bg-soft-red { background: #fee2e2; color: #ef4444; }

        /* Table */
        .custom-table {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.05);
        }

        .badge-active {
            background: #dcfce7;
            color: #16a34a;
            padding: 6px 12px;
            border-radius: 50px;
        }

    </style>
</head>

<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="mb-4">
        <h5>SportsFest</h5>
        <small>EVENT MANAGEMENT</small>
    </div>

    <a href="/admin/dashboard" class="active">
        <i class="bi bi-grid"></i> Dashboard
    </a>

	<a href="javascript:void(0);"
	   onclick="loadPage('/admin/events')">
	    <i class="bi bi-calendar-event"></i> Events
	</a>

	<a href="javascript:void(0);"
	   onclick="loadPage('/admin/registrations')">
	    <i class="bi bi-people"></i> Registrations
	</a>

    <a href="/logout">
        <i class="bi bi-box-arrow-left"></i> Logout
    </a>
</div>

<!-- Main Content -->
<div class="main" id="mainContent">

    <!-- Topbar -->
    <div class="topbar">
        <input type="text" class="search-input" placeholder="Search events, registrations...">

        <div class="d-flex align-items-center gap-3">
            <button class="btn btn-primary rounded-pill px-4"
                    onclick="openModal('/admin/create-event','Create Event')">
                + Create Event
            </button>

            <div class="profile-circle">AD</div>
        </div>
    </div>

    <!-- Page Title -->
    <div class="mb-4">
        <h3>Dashboard</h3>
        <p class="text-muted">Welcome back, Admin. Here's what's happening today.</p>
    </div>

    <!-- Stats Cards -->
    <div class="row g-4 mb-5">

        <div class="col-md-3">
            <div class="stat-card border-blue">
                <div class="icon-box bg-soft-blue">
                    <i class="bi bi-calendar"></i>
                </div>
                <h3>${totalEvents}</h3>
                <p class="text-muted mb-0">Total Events</p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="stat-card border-green">
                <div class="icon-box bg-soft-green">
                    <i class="bi bi-lightning"></i>
                </div>
                <h3>${activeEvents}</h3>
                <p class="text-muted mb-0">Active Events</p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="stat-card border-orange">
                <div class="icon-box bg-soft-orange">
                    <i class="bi bi-people"></i>
                </div>
                <h3>${totalRegistrations}</h3>
                <p class="text-muted mb-0">Registrations</p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="stat-card border-red">
                <div class="icon-box bg-soft-red">
                    <i class="bi bi-clock"></i>
                </div>
                <h3>${pendingCount}</h3>
                <p class="text-muted mb-0">Pending Approvals</p>
            </div>
        </div>

    </div>

    <!-- Recent Events Table -->
    <div class="custom-table">
        <div class="d-flex justify-content-between mb-3">
            <h5>Recent Events</h5>
			<button class="btn btn-sm btn-outline-secondary"
			        onclick="openModal('/admin/events','All Events')">
			    View All
			</button>
        </div>

        <table class="table align-middle">
            <thead class="text-muted">
                <tr>
                    <th>Event Name</th>
                    <th>Last Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="event" items="${events}">
                    <tr>
                        <td>${event.name}</td>
                        <td>${event.deadline}</td>
						<td>
						    <span class="badge ${event.active ? 'bg-success' : 'bg-secondary'}">
						        ${event.active ? 'Active' : 'Inactive'}
						    </span>
						</td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>
    </div>

</div>

<!-- Modal Loader -->
<div class="modal fade" id="globalModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Loading...</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="modalBody">
                <div class="text-center p-4">
                    <div class="spinner-border"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>

    // =========================
    // GLOBAL MODAL FORM HANDLER
    // =========================
    $(document).on("submit", "#globalModal form", function (e) {

        e.preventDefault();

        const form = $(this);
        const action = form.attr("action");
        const method = form.attr("method") || "post";

        $.ajax({
            url: action,
            type: method,
            data: form.serialize(),
            success: function () {

                // Properly close modal
                const modalEl = document.getElementById('globalModal');
                const modal = bootstrap.Modal.getInstance(modalEl);

                if (modal) {
                    modal.hide();
                }

                // Clean leftover backdrop (important!)
                $('.modal-backdrop').remove();
                $('body').removeClass('modal-open');
                $('body').css('padding-right', '');

                // Reload current page content
                loadPage(window.currentPage || '/admin/events');
            },
            error: function () {
                alert("Something went wrong!");
            }
        });
    });


    // =========================
    // OPEN MODAL FUNCTION
    // =========================
    function openModal(url, title) {

        const modalEl = document.getElementById('globalModal');
        const modal = new bootstrap.Modal(modalEl);

        $("#globalModal .modal-title").text(title);

        $("#modalBody").html(`
            <div class="text-center p-5">
                <div class="spinner-border text-primary"></div>
            </div>
        `);

        modal.show();

        $.ajax({
            url: url,
            success: function (data) {
                $("#modalBody").html(data);
            },
            error: function () {
                $("#modalBody").html(
                    `<div class="alert alert-danger">
                        Error loading content
                     </div>`
                );
            }
        });
    }


    // =========================
    // LOAD PAGE (MAIN CONTENT)
    // =========================
    function loadPage(url) {

        window.currentPage = url; // store last page

        $("#mainContent").html(`
            <div class="text-center p-5">
                <div class="spinner-border text-primary"></div>
            </div>
        `);

        $.get(url, function (data) {
            $("#mainContent").html(data);
        });
    }


    // =========================
    // SAFETY CLEANUP (VERY IMPORTANT)
    // =========================
    $(document).on('hidden.bs.modal', '#globalModal', function () {
        $('.modal-backdrop').remove();
        $('body').removeClass('modal-open');
        $('body').css('padding-right', '');
    });

</script>

</body>
</html>