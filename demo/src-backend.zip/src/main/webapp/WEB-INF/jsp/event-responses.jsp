<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<div>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="mb-0">${event.name} - Registrations</h5>

        <button class="btn btn-sm btn-secondary"
                onclick="openModal('/admin/events','Select Event')">
            Back
        </button>
    </div>

    <c:if test="${empty registrations}">
        <div class="alert alert-info">
            No registrations yet.
        </div>
    </c:if>

    <c:if test="${not empty registrations}">
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">

                <thead class="table-dark">
                <tr>
                    <th>ID</th>

                    <!-- Dynamic Headers -->
                    <c:forEach var="field" items="${fields}">
                        <th>${field.label}</th>
                    </c:forEach>

                    <th>Status</th>
                    <th>Action</th>
                </tr>
                </thead>

                <tbody>
                <c:forEach var="reg" items="${registrations}" varStatus="status">

                    <tr>
                        <td>${reg.registrationId}</td>

                        <!-- Dynamic Values -->
						<c:forEach var="field" items="${fields}">
						    <td>
						        ${parsedDataList[status.index][field.id.toString()]}
						    </td>
						</c:forEach>

                        <td>
                            <span class="badge 
                                ${reg.status == 'PENDING' ? 'bg-warning text-dark' :
                                  reg.status == 'APPROVED' ? 'bg-success' :
                                  'bg-danger'}">
                                ${reg.status}
                            </span>
                        </td>

                        <td>
                            <c:if test="${reg.status == 'PENDING'}">
                                <button class="btn btn-sm btn-success"
                                        onclick="approveReg(${reg.id})">
                                    Approve
                                </button>

                                <button class="btn btn-sm btn-danger"
                                        onclick="rejectReg(${reg.id})">
                                    Reject
                                </button>
                            </c:if>
                        </td>

                    </tr>

                </c:forEach>
                </tbody>

            </table>
        </div>
    </c:if>

</div>

<script>

function approveReg(id) {

    fetch('/admin/approve-registration/' + id, {
        method: 'POST'
    })
    .then(response => {
        if (response.ok) {
            // Reload modal content
            openModal('/admin/event-responses/${event.id}', 'Registrations - ${event.name}');
        } else {
            alert("Error approving registration");
        }
    });

}

function rejectReg(id) {

    fetch('/admin/reject-registration/' + id, {
        method: 'POST'
    })
    .then(response => {
        if (response.ok) {
            // Reload modal content
            openModal('/admin/event-responses/${event.id}', 'Registrations - ${event.name}');
        } else {
            alert("Error rejecting registration");
        }
    });

}

</script>