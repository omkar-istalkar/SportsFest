package com.example.demo.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entity.Event;
import com.example.demo.entity.FormField;
import com.example.demo.entity.Registration;
import com.example.demo.enums.RegistrationStatus;
import com.example.demo.service.EventService;
import com.example.demo.service.FormFieldService;
import com.example.demo.service.RegistrationService;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private EventService eventService;

	@Autowired
	private FormFieldService formFieldService;
	
	@Autowired
	private RegistrationService registrationService;
	
	@GetMapping("/dashboard")
	public String dashboard(Model model)
	{
		 model.addAttribute("totalEvents", eventService.getAllEvents().size());

		    // Active events
		    model.addAttribute("activeEvents", eventService.getActiveEvents().size());

		    // Total registrations
		    model.addAttribute("totalRegistrations",
		            registrationService.getAllRegistrations().size());

		    // Pending approvals
		    model.addAttribute("pendingCount",
		            registrationService.getRegistrationsByStatus(RegistrationStatus.PENDING).size());

		    // Recent events (for table)
		    model.addAttribute("events",
		            eventService.getAllEvents()); // you can limit later

		    return "admin-dashboard";
	}
	
	@GetMapping("/create-event")
	public String showCreateEventPage( Model model)
	{
		
		model.addAttribute("event", new Event());
		return "create-event";
	}
	
	@PostMapping("/save-event")
	public String saveEvent(@ModelAttribute Event event)
	{
		
		eventService.saveEvent(event);
		return "redirect:/admin/events";
	}
	
	@GetMapping("/events")
	public String listEvents(Model model)
	{

		model.addAttribute("events", eventService.getAllEvents());
		return "event-list";
	}
	
	@GetMapping("/add-field/{eventId}")
	public String showFieldPage(@PathVariable Long eventId, Model model, HttpSession session)
	{
			
		model.addAttribute("eventId", eventId);
		model.addAttribute("field", new FormField());
		return "add-field";
	}
	
	@PostMapping("/save-field/{eventId}")
	public String saveField(@PathVariable Long eventId, @ModelAttribute FormField field)
	{
	    formFieldService.saveField(eventId, field);
	    return "redirect:/admin/fields/" + eventId;
	}
	
	@GetMapping("/fields/{eventId}")
	public String viewFields(@PathVariable Long eventId, Model model) {
	    Event event = eventService.getEventById(eventId);
	    List<FormField> fields = formFieldService.getFieldsByEvent(eventId);

	    model.addAttribute("event", event);
	    model.addAttribute("fields", fields);

	    return "field-list";
	}
	
	@GetMapping("/edit-field/{id}")
	public String editField(@PathVariable Long id, Model model) {

	    FormField field = formFieldService.getFieldById(id);
	    model.addAttribute("field", field);

	    return "edit-field";
	}
	
	@PostMapping("/update-field")
	public String updateField(@ModelAttribute FormField field) {

	    formFieldService.updateField(field);

	    return "redirect:/admin/fields/" + field.getEvent().getId();
	}
	
	@GetMapping("/delete-field/{id}")
	public String deleteField(@PathVariable Long id) {

	    FormField field = formFieldService.getFieldById(id);
	    Long eventId = field.getEvent().getId();

	    formFieldService.deleteField(id);

	    return "redirect:/admin/fields/" + eventId;
	}
	
	@GetMapping("/delete-event/{id}")
	public String deleteEvent(@PathVariable Long id) {

	    eventService.deleteEvent(id);

	    return "redirect:/admin/events";
	}
	
	@GetMapping("/edit-event/{id}")
	public String editEvent(@PathVariable Long id, Model model) {

	    Event event = eventService.getEventById(id);
	    model.addAttribute("event", event);

	    return "edit-event";
	}
	
	@PostMapping("/update-event")
	public String updateEvent(@ModelAttribute Event event) {

	    eventService.updateEvent(event);

	    return "redirect:/admin/events";
	}
	
	@GetMapping("/toggle-event/{id}")
	public String toggleEvent(@PathVariable Long id) {

	    eventService.toggleEventStatus(id);

	    return "redirect:/admin/events";
	}
	
	@GetMapping("/preview/{eventId}")
	public String previewEvent(@PathVariable Long eventId, Model model) {

	    Event event = eventService.getEventById(eventId);
	    List<FormField> fields = formFieldService.getFieldsByEvent(eventId);

	    model.addAttribute("event", event);
	    model.addAttribute("fields", fields);

	    return "preview-event";
	}
	
	@GetMapping("/event-responses/{eventId}")
	public String eventResponses(@PathVariable Long eventId, Model model) {

	    Event event = eventService.getEventById(eventId);
	    List<FormField> fields = formFieldService.getFieldsByEvent(eventId);

	    List<Registration> registrations =
	            registrationService.getRegistrationsByEvent(eventId);

	    ObjectMapper mapper = new ObjectMapper();
	    List<Map<String, String>> parsedDataList = new ArrayList<>();

	    for (Registration reg : registrations) {
	        try {
	            @SuppressWarnings("unchecked")
				Map<String, String> map =
	                    mapper.readValue(reg.getDynamicData(), Map.class);
	            parsedDataList.add(map);
	        } catch (Exception e) {
	            parsedDataList.add(new HashMap<>());
	        }
	    }

	    model.addAttribute("event", event);
	    model.addAttribute("fields", fields);
	    model.addAttribute("registrations", registrations);
	    model.addAttribute("parsedDataList", parsedDataList);

	    return "event-responses";
	}
	
	@PostMapping("/approve-registration/{id}")
	public String approveRegistration(@PathVariable Long id) {
	    registrationService.updateStatus(id, RegistrationStatus.APPROVED);
	    return "redirect:/admin/registrations";
	}

	@PostMapping("/reject-registration/{id}")
	public String rejectRegistration(@PathVariable Long id) {
	    registrationService.updateStatus(id, RegistrationStatus.REJECTED);
	    return "redirect:/admin/registrations";
	}
	
	@GetMapping("/registrations")
	public String allRegistrations(Model model) {

	    List<Registration> registrations = registrationService.getAllRegistrations();

	    long pending = registrations.stream()
	            .filter(r -> r.getStatus() == RegistrationStatus.PENDING)
	            .count();

	    long approved = registrations.stream()
	            .filter(r -> r.getStatus() == RegistrationStatus.APPROVED)
	            .count();

	    long rejected = registrations.stream()
	            .filter(r -> r.getStatus() == RegistrationStatus.REJECTED)
	            .count();

	    model.addAttribute("registrations", registrations);
	    model.addAttribute("pendingCount", pending);
	    model.addAttribute("approvedCount", approved);
	    model.addAttribute("rejectedCount", rejected);

	    return "registrations";
	}
	
	@GetMapping("/view-registration/{id}")
	public String viewRegistration(@PathVariable Long id, Model model) {

	    Registration reg = registrationService.findById(id);

	    // Parse dynamic JSON
	    try {
	    	ObjectMapper mapper = new ObjectMapper();
	    	@SuppressWarnings("unchecked")
			Map<String, String> dynamicData =
	    	        mapper.readValue(reg.getDynamicData(), Map.class);

	    	// Fetch all fields of this event
	    	List<FormField> fields =
	    	        formFieldService.getFieldsByEvent(reg.getEvent().getId());

	    	// Map fieldId -> label
	    	Map<String, String> labeledData = new LinkedHashMap<>();

	    	for (FormField field : fields) {
	    	    String value = dynamicData.get(String.valueOf(field.getId()));
	    	    if (value != null) {
	    	        labeledData.put(field.getLabel(), value);
	    	    }
	    	}

	    	model.addAttribute("dynamicData", labeledData);
	    } catch (Exception e) {
	        model.addAttribute("dynamicData", null);
	    }

	    model.addAttribute("registration", reg);

	    return "view-registration";
	}
}
